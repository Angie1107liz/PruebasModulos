package com.sena.shoes_store.interfaceService;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.sena.shoes_store.model.productos;

@Service
public interface IproductosService {
    
    public String save (productos productos);
	public List<productos>findAll();
	public List<productos> filtroProductos(String filtro);
	public List<productos> filtroNombreProducto(String nombre_producto);
    public List<productos> filtroEstadoProducto(String estado);
	public Optional<productos> findOne(String id);
	public int delete(String id);
}
