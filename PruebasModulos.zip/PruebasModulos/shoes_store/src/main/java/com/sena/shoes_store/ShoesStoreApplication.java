package com.sena.shoes_store;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoesStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoesStoreApplication.class, args);
	}

}
