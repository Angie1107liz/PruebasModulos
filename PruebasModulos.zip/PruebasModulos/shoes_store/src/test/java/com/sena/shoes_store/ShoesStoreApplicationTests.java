package com.sena.shoes_store;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoesStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
